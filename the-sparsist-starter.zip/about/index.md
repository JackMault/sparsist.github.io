---
layout: default
title: About
description: Who we are, how we think, and why signal beats noise.
---
<h1>About The Sparsist</h1>
<p>We operate like engineers of identity and value. Clear offers. Honest math. Durable growth.</p>
