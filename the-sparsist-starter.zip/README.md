# The Sparsist — Jekyll Starter
Deploy on GitHub Pages.
