---
layout: default
title: Pricing
description: Transparent, outcome‑aligned pricing.
---
<h1>Pricing</h1>
<div class="grid">
  <div class="card"><h3>Founder Identity Intensive</h3><p>Starts at $7,500</p></div>
  <div class="card"><h3>Executive Alignment Sprint (90 days)</h3><p>Starts at $18,000</p></div>
  <div class="card"><h3>Team Narrative Calibration</h3><p>Starts at $12,000</p></div>
</div>
<p class="sub">Custom scopes available. Fixed-fee, milestone-based. Ask about ND pilot rates.</p>
<div class="cta"><a class="btn primary" href="/contact/">Request a scope</a></div>
